function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEntryDisplayEntryDisplayComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>Journals</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Journals</ion-title>\n    </ion-toolbar>\n    <!--<ion-toolbar>\n      <ion-searchbar showCancelButton=\"focus\"></ion-searchbar>\n    </ion-toolbar>-->\n  </ion-header>\n\n  <div *ngIf=\"showJournals\">\n    <div *ngIf=\"memories.length > 0\">\n      <h2 class=\"ion-padding-start ion-padding-start\">Memories</h2>\n      <ion-slides [options]=\"{ slidesPerView: 1.2, spaceBetween: 0 }\">\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>My day was something.</ion-card-title>\n              <ion-card-subtitle>Friday, July 3, 2020 8:05 pm</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'Where do I even begin? Cause I can\\'t EVEN with today! So it started...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>Chased by a bear</ion-card-title>\n              <ion-card-subtitle>Saturday, June 20, 2020 5:00 am</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'Today was a wild day... I was just walking to the bus and here comes a giant bear! And I was like...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>Made a chair</ion-card-title>\n              <ion-card-subtitle>Tuesday, November 19, 2020 8:00pm</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'It was like the cutest chair I\\'ve every seen... I painted it bright pink and added...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n      </ion-slides>\n    </div>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col sizeLg=\"6\" sizeMd=\"6\" sizeXs=\"12\" *ngFor=\"let journal of journals; let i = index;\">\n          <ion-card (click)=\"openJournalPage('/tabs/journalView', journal)\" style=\"margin-bottom: 0px; margin-top: 8px;\">\n            <ion-card-header>\n              <ion-card-title>{{ journal.name }}</ion-card-title>\n              <ion-card-subtitle>{{ dateFormatted[i] }}</ion-card-subtitle>\n              <ion-card-subtitle *ngIf=\"journal.locked\"><ion-badge color=\"danger\">Locked</ion-badge></ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"journalContentFormatted[i] | words : 25\">\n            </ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-infinite-scroll threshold=\"80px\" (ionInfinite)=\"loadData($event)\">\n      <ion-infinite-scroll-content\n              loadingSpinner=\"bubbles\"\n              loadingText=\"Loading more journal entries...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n    <br/><br/><br/><br/>\n  </div>\n\n  <ion-card *ngIf=\"!showJournals\">\n    <ion-card-content style=\"text-align: center;\">\n      No journals... why don't you <a (click)=\"openPage('/tabs/journalNew')\">create one</a>?\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" style=\"margin-bottom: 10pt;\">\n    <ion-fab-button>\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"top\">\n      <ion-fab-button (click)=\"openPage('/tabs/journalNew')\"><ion-icon name=\"add\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"start\">\n      <ion-fab-button (click)=\"unlockLockJournals()\"><ion-icon [name]=\"lockIcon\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"end\">\n      <ion-fab-button (click)=\"openSettings()\"><ion-icon name=\"cog\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/entry-display/entry-display.component.scss":
  /*!************************************************************!*\
    !*** ./src/app/entry-display/entry-display.component.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEntryDisplayEntryDisplayComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VudHJ5LWRpc3BsYXkvZW50cnktZGlzcGxheS5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/entry-display/entry-display.component.ts":
  /*!**********************************************************!*\
    !*** ./src/app/entry-display/entry-display.component.ts ***!
    \**********************************************************/

  /*! exports provided: EntryDisplayComponent */

  /***/
  function srcAppEntryDisplayEntryDisplayComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EntryDisplayComponent", function () {
      return EntryDisplayComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var EntryDisplayComponent = /*#__PURE__*/function () {
      function EntryDisplayComponent() {
        _classCallCheck(this, EntryDisplayComponent);
      }

      _createClass(EntryDisplayComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return EntryDisplayComponent;
    }();

    EntryDisplayComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-entry-display',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./entry-display.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./entry-display.component.scss */
      "./src/app/entry-display/entry-display.component.scss"))["default"]]
    })], EntryDisplayComponent);
    /***/
  },

  /***/
  "./src/app/home/home-routing.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/home/home-routing.module.ts ***!
    \*********************************************/

  /*! exports provided: HomePageRoutingModule */

  /***/
  function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
      return HomePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");

    var routes = [{
      path: '',
      component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }];

    var HomePageRoutingModule = function HomePageRoutingModule() {
      _classCallCheck(this, HomePageRoutingModule);
    };

    HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/home/home.module.ts":
  /*!*************************************!*\
    !*** ./src/app/home/home.module.ts ***!
    \*************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home-routing.module */
    "./src/app/home/home-routing.module.ts");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");
    /* harmony import */


    var _entry_display_entry_display_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../entry-display/entry-display.component */
    "./src/app/entry-display/entry-display.component.ts");
    /* harmony import */


    var _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @yellowspot/ng-truncate */
    "./node_modules/@yellowspot/ng-truncate/__ivy_ngcc__/fesm2015/yellowspot-ng-truncate.js");

    var HomePageModule = function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    };

    HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"], _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_8__["TruncateModule"]],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"], _entry_display_entry_display_component__WEBPACK_IMPORTED_MODULE_7__["EntryDisplayComponent"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/home/home.page.scss":
  /*!*************************************!*\
    !*** ./src/app/home/home.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/home/home.page.ts":
  /*!***********************************!*\
    !*** ./src/app/home/home.page.ts ***!
    \***********************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/native-page-transitions/ngx */
    "./node_modules/@ionic-native/native-page-transitions/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/native-storage/ngx */
    "./node_modules/@ionic-native/native-storage/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _settings_settings_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../settings/settings.component */
    "./src/app/settings/settings.component.ts");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! crypto-js */
    "./node_modules/crypto-js/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_8__);
    /* harmony import */


    var _password_dialog_password_dialog_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../password-dialog/password-dialog.component */
    "./src/app/password-dialog/password-dialog.component.ts");
    /* harmony import */


    var _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/taptic-engine/ngx */
    "./node_modules/@ionic-native/taptic-engine/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _welcome_screen_welcome_screen_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ../welcome-screen/welcome-screen.component */
    "./src/app/welcome-screen/welcome-screen.component.ts");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");

    var Filesystem = _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["Plugins"].Filesystem;
    var options = {
      direction: 'left',
      duration: 500,
      slowdownfactor: 3,
      slidePixels: 60,
      iosdelay: 0,
      androiddelay: 0,
      fixedPixelsTop: 0,
      fixedPixelsBottom: 60
    };

    var HomePage = /*#__PURE__*/function () {
      function HomePage(modalController, taptic, alertController, platform, nativePageTransitions, routerOutlet, navCtrl, nativeStorage, file) {
        _classCallCheck(this, HomePage);

        this.modalController = modalController;
        this.taptic = taptic;
        this.alertController = alertController;
        this.platform = platform;
        this.nativePageTransitions = nativePageTransitions;
        this.routerOutlet = routerOutlet;
        this.navCtrl = navCtrl;
        this.nativeStorage = nativeStorage;
        this.file = file;
        this.showJournals = false;
        this.journals = [];
        this.dateFormatted = [];
        this.journalContentFormatted = [];
        this.sortedJournals = [];
        this.showLoadmore = false;
        this.lockIcon = 'lock-closed-outline';
        this.memories = [];
      }

      _createClass(HomePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          }));
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          var _this = this;

          this.platform.ready().then(function () {
            _this.loadJournal();
          })["catch"](function (err) {
            console.log('Error loading platform: ' + JSON.stringify(err));
          });
        }
      }, {
        key: "stripJournalContent",
        value: function stripJournalContent(content) {
          var tagsToStrip = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7'];

          for (var i in tagsToStrip) {
            content = content.replace(new RegExp('<' + tagsToStrip[i] + '.*>.*?<\/' + tagsToStrip[i] + '>'), '');
          }

          return content.split('\n', 1)[0].trim();
        }
      }, {
        key: "customSort",
        value: function customSort(a, b) {
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        }
      }, {
        key: "deleteJournal",
        value: function deleteJournal(data) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var contents, outParsed, i, result;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return Filesystem.readFile({
                      path: 'Mirror-app/mirrorJournals.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    });

                  case 2:
                    contents = _context2.sent;
                    outParsed = JSON.parse(contents.data);
                    _context2.t0 = regeneratorRuntime.keys(outParsed);

                  case 5:
                    if ((_context2.t1 = _context2.t0()).done) {
                      _context2.next = 24;
                      break;
                    }

                    i = _context2.t1.value;

                    if (!outParsed.hasOwnProperty(i)) {
                      _context2.next = 22;
                      break;
                    }

                    if (!(outParsed[i].id === data.id)) {
                      _context2.next = 22;
                      break;
                    }

                    outParsed = outParsed.filter(function (returnableObjects) {
                      return returnableObjects.id !== data.id;
                    });
                    _context2.next = 12;
                    return Filesystem.deleteFile({
                      path: 'Mirror-app/' + data.id + '.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents
                    });

                  case 12:
                    _context2.prev = 12;
                    _context2.next = 15;
                    return Filesystem.writeFile({
                      path: 'Mirror-app/' + data.id + '.txt',
                      data: JSON.stringify(outParsed),
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    });

                  case 15:
                    result = _context2.sent;
                    console.log('Wrote file', result);
                    _context2.next = 22;
                    break;

                  case 19:
                    _context2.prev = 19;
                    _context2.t2 = _context2["catch"](12);
                    console.error('Unable to write file', _context2.t2);

                  case 22:
                    _context2.next = 5;
                    break;

                  case 24:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, null, [[12, 19]]);
          }));
        }
      }, {
        key: "loadNextJournal",
        value: function loadNextJournal(id, numberLoaded) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this2 = this;

            var contents, output;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return Filesystem.readFile({
                      path: 'Mirror-app/' + id + '.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    });

                  case 2:
                    contents = _context3.sent;
                    output = JSON.parse(contents.data);
                    /* tslint:disable:no-string-literal */

                    if (!output['locked'] || this.passcode !== undefined && output['locked']) {
                      if (output['locked']) {
                        output['content'] = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(output['content'], this.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8);

                        if (output['notes']) {
                          output['notes'] = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(output['notes'], this.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8);
                        }
                      }

                      output['id'] = id;
                      this.journals.push(output);
                      this.showJournals = this.journals.length > 0;
                      this.dateFormatted = [];
                      this.journalContentFormatted = [];
                      this.journals.forEach(function (item, index) {
                        // Todo: Yeah no I was right this is gross.
                        var timeToExpireString = _this2.journals[index].expire.split(' ');

                        var timeToExpireMoment = moment__WEBPACK_IMPORTED_MODULE_5__(_this2.journals[index].date);
                        var hourDiff = moment__WEBPACK_IMPORTED_MODULE_5__().diff(timeToExpireMoment, 'hours');
                        var hoursToCountdown;

                        if (timeToExpireString[1] === 'Days' || timeToExpireString[1] === 'Day') {
                          hoursToCountdown = timeToExpireString[0] * 24;
                        } else if (timeToExpireString[1] === 'Weeks' || timeToExpireString[1] === 'Week') {
                          hoursToCountdown = timeToExpireString[0] * 7 * 24;
                        } else if (timeToExpireString[1] === 'Months' || timeToExpireString[1] === 'Month') {
                          hoursToCountdown = timeToExpireString[0] * 30 * 24;
                        } else if (timeToExpireString[1] === 'Years' || timeToExpireString[1] === 'Year') {
                          hoursToCountdown = timeToExpireString[0] * 365 * 24;
                        }

                        var hoursLeft = Math.round(hoursToCountdown - hourDiff);

                        if (hoursLeft < 0) {
                          _this2.deleteJournal(_this2.journals[index]);

                          _this2.journalsLoaded -= 1;
                          _this2.sortedJournals = _this2.sortedJournals.filter(function (returnableObjects) {
                            return returnableObjects.date !== _this2.journals[index].date;
                          });
                        } else {
                          _this2.dateFormatted.push(moment__WEBPACK_IMPORTED_MODULE_5__(_this2.journals[index].date).format('LLLL'));

                          _this2.journalContentFormatted.push(_this2.stripJournalContent(_this2.journals[index].content));
                        }
                      });
                      this.loadNextFiveJournals(numberLoaded + 1);
                    } else {
                      this.loadNextFiveJournals(numberLoaded);
                    }

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "loadNextFiveJournals",
        value: function loadNextFiveJournals(numberLoaded) {
          for (var i in this.sortedJournals) {
            if (this.sortedJournals.hasOwnProperty(i)) {
              if (parseInt(i) + 1 > this.journalsLoaded && numberLoaded <= 5) {
                this.loadNextJournal(this.sortedJournals[i].id, numberLoaded);
                this.journalsLoaded += 1;
                break;
              }
            }
          }

          this.showLoadmore = this.journalsLoaded < this.sortedJournals.length;
        }
      }, {
        key: "loadData",
        value: function loadData(event) {
          var _this3 = this;

          setTimeout(function () {
            _this3.loadNextFiveJournals(1);

            event.target.complete();

            if (!_this3.showLoadmore) {
              event.target.disabled = true;
            }
          }, 500);
        }
      }, {
        key: "createMirrorJournals",
        value: function createMirrorJournals() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var result;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.prev = 0;
                    _context4.next = 3;
                    return Filesystem.mkdir({
                      path: 'Mirror-app',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      recursive: false // like mkdir -p

                    });

                  case 3:
                    _context4.prev = 3;
                    _context4.next = 6;
                    return Filesystem.writeFile({
                      path: 'Mirror-app/mirrorJournals.txt',
                      data: '[]',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    });

                  case 6:
                    result = _context4.sent;
                    this.showWelcomeSceen();
                    console.log('Wrote file', result);
                    _context4.next = 14;
                    break;

                  case 11:
                    _context4.prev = 11;
                    _context4.t0 = _context4["catch"](3);
                    console.error('Unable to write file', _context4.t0);

                  case 14:
                    _context4.next = 19;
                    break;

                  case 16:
                    _context4.prev = 16;
                    _context4.t1 = _context4["catch"](0);
                    console.error('Unable to make directory', _context4.t1);

                  case 19:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this, [[0, 16], [3, 11]]);
          }));
        }
      }, {
        key: "loadJournal",
        value: function loadJournal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this4 = this;

            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    this.dateFormatted = [];
                    this.journalContentFormatted = [];
                    this.journals = [];
                    this.showJournals = false;
                    this.journalsLoaded = 0;
                    Filesystem.readFile({
                      path: 'Mirror-app/mirrorJournals.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    }).then(function (contents) {
                      _this4.sortedJournals = JSON.parse(contents.data);

                      _this4.sortedJournals.sort(function (a, b) {
                        return Number(new Date(b.date)) - Number(new Date(a.date));
                      });

                      _this4.loadNextFiveJournals(1);
                    })["catch"](function (e) {
                      console.error('file read err', e);

                      _this4.createMirrorJournals();

                      _this4.showJournals = false;
                    });

                  case 6:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "showWelcomeSceen",
        value: function showWelcomeSceen() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var modal;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.modalController.create({
                      component: _welcome_screen_welcome_screen_component__WEBPACK_IMPORTED_MODULE_11__["WelcomeScreenComponent"],
                      backdropDismiss: false
                    });

                  case 2:
                    modal = _context6.sent;
                    _context6.next = 5;
                    return modal.present();

                  case 5:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {
          // this.nativePageTransitions.slide(options);
          this.routerOutlet.swipeGesture = true;
        } // example of adding a transition when pushing a new page

      }, {
        key: "openJournalPage",
        value: function openJournalPage(page, journalToNavigate) {
          this.taptic.selection(); // this.nativePageTransitions.slide(options);

          var navigationExtras;

          if (this.passcode !== undefined) {
            navigationExtras = {
              state: {
                journal: journalToNavigate,
                passcode: this.passcode
              }
            };
          } else {
            navigationExtras = {
              state: {
                journal: journalToNavigate
              }
            };
          }

          this.navCtrl.navigateForward(page, navigationExtras);
        }
      }, {
        key: "openPage",
        value: function openPage(page) {
          this.taptic.selection();
          this.navCtrl.navigateForward(page).then(function () {})["catch"](function (err) {
            console.log('Error openPage: ' + err);
          });
        }
      }, {
        key: "openSettings",
        value: function openSettings() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this5 = this;

            var modal;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    this.taptic.selection();
                    _context7.next = 3;
                    return this.modalController.create({
                      component: _settings_settings_component__WEBPACK_IMPORTED_MODULE_7__["SettingsComponent"]
                    });

                  case 3:
                    modal = _context7.sent;
                    modal.onDidDismiss().then(function () {
                      _this5.passcode = undefined;
                      _this5.lockIcon = 'lock-closed-outline';

                      _this5.loadJournal();
                    });
                    _context7.next = 7;
                    return modal.present();

                  case 7:
                    return _context7.abrupt("return", _context7.sent);

                  case 8:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "openPasswordDialog",
        value: function openPasswordDialog() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            var _this6 = this;

            var modal;
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    this.taptic.notification({
                      type: 'warning'
                    });
                    _context8.next = 3;
                    return this.modalController.create({
                      component: _password_dialog_password_dialog_component__WEBPACK_IMPORTED_MODULE_9__["PasswordDialogComponent"]
                    });

                  case 3:
                    modal = _context8.sent;
                    modal.onDidDismiss().then(function (dataReturned) {
                      if (dataReturned !== null && dataReturned.data !== '') {
                        _this6.passcode = dataReturned.data;
                      }

                      _this6.loadJournal();
                    });
                    _context8.next = 7;
                    return modal.present();

                  case 7:
                    return _context8.abrupt("return", _context8.sent);

                  case 8:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "askForPasscode",
        value: function askForPasscode() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
            var _this7 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    _context9.next = 2;
                    return this.alertController.create({
                      message: 'What is your passcode?',
                      inputs: [{
                        name: 'passcode',
                        type: 'password',
                        placeholder: 'passcode',
                        attributes: {
                          inputmode: 'numeric',
                          pattern: '[0-9]*'
                        }
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                          _this7.passcode = undefined;

                          _this7.taptic.selection();
                        }
                      }, {
                        text: 'Ok',
                        handler: function handler(out) {
                          if (crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(_this7.passcode, out.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8) === 'passcode') {
                            _this7.passcode = out.passcode;
                            _this7.lockIcon = 'lock-open-outline';

                            _this7.taptic.notification({
                              type: 'success'
                            });

                            _this7.loadJournal();
                          } else {
                            _this7.passcode = undefined;

                            _this7.taptic.notification({
                              type: 'error'
                            });

                            _this7.unlockLockJournals();
                          }
                        }
                      }]
                    });

                  case 2:
                    alert = _context9.sent;
                    _context9.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }, {
        key: "unlockLockJournals",
        value: function unlockLockJournals() {
          var _this8 = this;

          if (this.passcode === undefined) {
            this.nativeStorage.getItem('passcode').then(function (out) {
              _this8.passcode = out;

              _this8.taptic.selection();

              _this8.askForPasscode();
            })["catch"](function (err) {
              _this8.openPasswordDialog();

              console.log('Error unlocklock: ' + JSON.stringify(err));
            });
          } else {
            this.passcode = undefined;
            this.lockIcon = 'lock-closed-outline';
            this.loadJournal();
          }
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__["TapticEngine"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_3__["NativePageTransitions"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonRouterOutlet"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__["NativeStorage"]
      }, {
        type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"])], HomePage.prototype, "infiniteScroll", void 0);
    HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/home/home.page.scss"))["default"]]
    })], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map