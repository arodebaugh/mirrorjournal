(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>Journals</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Journals</ion-title>\n    </ion-toolbar>\n    <!--<ion-toolbar>\n      <ion-searchbar showCancelButton=\"focus\"></ion-searchbar>\n    </ion-toolbar>-->\n  </ion-header>\n\n  <div *ngIf=\"showJournals\">\n    <div *ngIf=\"memories.length > 0\">\n      <h2 class=\"ion-padding-start ion-padding-start\">Memories</h2>\n      <ion-slides [options]=\"{ slidesPerView: 1.2, spaceBetween: 0 }\">\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>My day was something.</ion-card-title>\n              <ion-card-subtitle>Friday, July 3, 2020 8:05 pm</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'Where do I even begin? Cause I can\\'t EVEN with today! So it started...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>Chased by a bear</ion-card-title>\n              <ion-card-subtitle>Saturday, June 20, 2020 5:00 am</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'Today was a wild day... I was just walking to the bus and here comes a giant bear! And I was like...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n        <ion-slide>\n          <ion-card style=\"text-align: left;\">\n            <ion-card-header>\n              <ion-card-title>Made a chair</ion-card-title>\n              <ion-card-subtitle>Tuesday, November 19, 2020 8:00pm</ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"'It was like the cutest chair I\\'ve every seen... I painted it bright pink and added...'\">\n            </ion-card-content>\n          </ion-card>\n        </ion-slide>\n      </ion-slides>\n    </div>\n\n    <ion-grid>\n      <ion-row>\n        <ion-col sizeLg=\"6\" sizeMd=\"6\" sizeXs=\"12\" *ngFor=\"let journal of journals; let i = index;\">\n          <ion-card (click)=\"openJournalPage('/tabs/journalView', journal)\" style=\"margin-bottom: 0px; margin-top: 8px;\">\n            <ion-card-header>\n              <ion-card-title>{{ journal.name }}</ion-card-title>\n              <ion-card-subtitle>{{ dateFormatted[i] }}</ion-card-subtitle>\n              <ion-card-subtitle *ngIf=\"journal.locked\"><ion-badge color=\"danger\">Locked</ion-badge></ion-card-subtitle>\n            </ion-card-header>\n\n            <ion-card-content [innerHTML]=\"journalContentFormatted[i] | words : 25\">\n            </ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-infinite-scroll threshold=\"80px\" (ionInfinite)=\"loadData($event)\">\n      <ion-infinite-scroll-content\n              loadingSpinner=\"bubbles\"\n              loadingText=\"Loading more journal entries...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n    <br/><br/><br/><br/>\n  </div>\n\n  <ion-card *ngIf=\"!showJournals\">\n    <ion-card-content style=\"text-align: center;\">\n      No journals... why don't you <a (click)=\"openPage('/tabs/journalNew')\">create one</a>?\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" style=\"margin-bottom: 10pt;\">\n    <ion-fab-button>\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"top\">\n      <ion-fab-button (click)=\"openPage('/tabs/journalNew')\"><ion-icon name=\"add\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"start\">\n      <ion-fab-button (click)=\"unlockLockJournals()\"><ion-icon [name]=\"lockIcon\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"end\">\n      <ion-fab-button (click)=\"openSettings()\"><ion-icon name=\"cog\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/entry-display/entry-display.component.scss":
/*!************************************************************!*\
  !*** ./src/app/entry-display/entry-display.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VudHJ5LWRpc3BsYXkvZW50cnktZGlzcGxheS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/entry-display/entry-display.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/entry-display/entry-display.component.ts ***!
  \**********************************************************/
/*! exports provided: EntryDisplayComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EntryDisplayComponent", function() { return EntryDisplayComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let EntryDisplayComponent = class EntryDisplayComponent {
    constructor() { }
    ngOnInit() { }
};
EntryDisplayComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-entry-display',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./entry-display.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/entry-display/entry-display.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./entry-display.component.scss */ "./src/app/entry-display/entry-display.component.scss")).default]
    })
], EntryDisplayComponent);



/***/ }),

/***/ "./src/app/home/home-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HomePageRoutingModule);



/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home-routing.module */ "./src/app/home/home-routing.module.ts");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");
/* harmony import */ var _entry_display_entry_display_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../entry-display/entry-display.component */ "./src/app/entry-display/entry-display.component.ts");
/* harmony import */ var _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @yellowspot/ng-truncate */ "./node_modules/@yellowspot/ng-truncate/__ivy_ngcc__/fesm2015/yellowspot-ng-truncate.js");









let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"],
            _yellowspot_ng_truncate__WEBPACK_IMPORTED_MODULE_8__["TruncateModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"], _entry_display_entry_display_component__WEBPACK_IMPORTED_MODULE_7__["EntryDisplayComponent"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/native-page-transitions/ngx */ "./node_modules/@ionic-native/native-page-transitions/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _settings_settings_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../settings/settings.component */ "./src/app/settings/settings.component.ts");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _password_dialog_password_dialog_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../password-dialog/password-dialog.component */ "./src/app/password-dialog/password-dialog.component.ts");
/* harmony import */ var _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/taptic-engine/ngx */ "./node_modules/@ionic-native/taptic-engine/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _welcome_screen_welcome_screen_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../welcome-screen/welcome-screen.component */ "./src/app/welcome-screen/welcome-screen.component.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");













const { Filesystem } = _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["Plugins"];
const options = {
    direction: 'left',
    duration: 500,
    slowdownfactor: 3,
    slidePixels: 60,
    iosdelay: 0,
    androiddelay: 0,
    fixedPixelsTop: 0,
    fixedPixelsBottom: 60
};
let HomePage = class HomePage {
    constructor(modalController, taptic, alertController, platform, nativePageTransitions, routerOutlet, navCtrl, nativeStorage, file) {
        this.modalController = modalController;
        this.taptic = taptic;
        this.alertController = alertController;
        this.platform = platform;
        this.nativePageTransitions = nativePageTransitions;
        this.routerOutlet = routerOutlet;
        this.navCtrl = navCtrl;
        this.nativeStorage = nativeStorage;
        this.file = file;
        this.showJournals = false;
        this.journals = [];
        this.dateFormatted = [];
        this.journalContentFormatted = [];
        this.sortedJournals = [];
        this.showLoadmore = false;
        this.lockIcon = 'lock-closed-outline';
        this.memories = [];
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // this.loadJounal();
        });
    }
    ionViewDidEnter() {
        this.platform.ready().then(() => {
            this.loadJournal();
        }).catch((err) => {
            console.log('Error loading platform: ' + JSON.stringify(err));
        });
    }
    stripJournalContent(content) {
        const tagsToStrip = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7'];
        for (const i in tagsToStrip) {
            content = content.replace(new RegExp('<' + tagsToStrip[i] + '.*>.*?<\/' + tagsToStrip[i] + '>'), '');
        }
        return content.split('\n', 1)[0].trim();
    }
    customSort(a, b) {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
    }
    deleteJournal(data) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const contents = yield Filesystem.readFile({
                path: 'Mirror-app/mirrorJournals.txt',
                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
            });
            let outParsed = JSON.parse(contents.data);
            for (const i in outParsed) {
                if (outParsed.hasOwnProperty(i)) {
                    if (outParsed[i].id === data.id) {
                        outParsed = outParsed.filter(returnableObjects => returnableObjects.id !== data.id);
                        yield Filesystem.deleteFile({
                            path: 'Mirror-app/' + data.id + '.txt',
                            directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents
                        });
                        try {
                            const result = yield Filesystem.writeFile({
                                path: 'Mirror-app/' + data.id + '.txt',
                                data: JSON.stringify(outParsed),
                                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                            });
                            console.log('Wrote file', result);
                        }
                        catch (e) {
                            console.error('Unable to write file', e);
                        }
                    }
                }
            }
        });
    }
    loadNextJournal(id, numberLoaded) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const contents = yield Filesystem.readFile({
                path: 'Mirror-app/' + id + '.txt',
                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
            });
            const output = JSON.parse(contents.data);
            /* tslint:disable:no-string-literal */
            if (!output['locked'] || (this.passcode !== undefined && output['locked'])) {
                if (output['locked']) {
                    output['content'] = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(output['content'], this.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8);
                    if (output['notes']) {
                        output['notes'] = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(output['notes'], this.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8);
                    }
                }
                output['id'] = id;
                this.journals.push(output);
                this.showJournals = this.journals.length > 0;
                this.dateFormatted = [];
                this.journalContentFormatted = [];
                this.journals.forEach((item, index) => {
                    // Todo: Yeah no I was right this is gross.
                    const timeToExpireString = this.journals[index].expire.split(' ');
                    const timeToExpireMoment = moment__WEBPACK_IMPORTED_MODULE_5__(this.journals[index].date);
                    const hourDiff = moment__WEBPACK_IMPORTED_MODULE_5__().diff(timeToExpireMoment, 'hours');
                    let hoursToCountdown;
                    if (timeToExpireString[1] === 'Days' || timeToExpireString[1] === 'Day') {
                        hoursToCountdown = timeToExpireString[0] * 24;
                    }
                    else if (timeToExpireString[1] === 'Weeks' || timeToExpireString[1] === 'Week') {
                        hoursToCountdown = (timeToExpireString[0] * 7) * 24;
                    }
                    else if (timeToExpireString[1] === 'Months' || timeToExpireString[1] === 'Month') {
                        hoursToCountdown = (timeToExpireString[0] * 30) * 24;
                    }
                    else if (timeToExpireString[1] === 'Years' || timeToExpireString[1] === 'Year') {
                        hoursToCountdown = (timeToExpireString[0] * 365) * 24;
                    }
                    const hoursLeft = Math.round(hoursToCountdown - hourDiff);
                    if (hoursLeft < 0) {
                        this.deleteJournal(this.journals[index]);
                        this.journalsLoaded -= 1;
                        this.sortedJournals = this.sortedJournals.filter(returnableObjects => returnableObjects.date !== this.journals[index].date);
                    }
                    else {
                        this.dateFormatted.push(moment__WEBPACK_IMPORTED_MODULE_5__(this.journals[index].date).format('LLLL'));
                        this.journalContentFormatted.push(this.stripJournalContent(this.journals[index].content));
                    }
                });
                this.loadNextFiveJournals(numberLoaded + 1);
            }
            else {
                this.loadNextFiveJournals(numberLoaded);
            }
        });
    }
    loadNextFiveJournals(numberLoaded) {
        for (const i in this.sortedJournals) {
            if (this.sortedJournals.hasOwnProperty(i)) {
                if (((parseInt(i) + 1) > this.journalsLoaded) && (numberLoaded <= 5)) {
                    this.loadNextJournal(this.sortedJournals[i].id, numberLoaded);
                    this.journalsLoaded += 1;
                    break;
                }
            }
        }
        this.showLoadmore = this.journalsLoaded < this.sortedJournals.length;
    }
    loadData(event) {
        setTimeout(() => {
            this.loadNextFiveJournals(1);
            event.target.complete();
            if (!this.showLoadmore) {
                event.target.disabled = true;
            }
        }, 500);
    }
    createMirrorJournals() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                yield Filesystem.mkdir({
                    path: 'Mirror-app',
                    directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                    recursive: false // like mkdir -p
                });
                try {
                    const result = yield Filesystem.writeFile({
                        path: 'Mirror-app/mirrorJournals.txt',
                        data: '[]',
                        directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                        encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
                    });
                    this.showWelcomeSceen();
                    console.log('Wrote file', result);
                }
                catch (e) {
                    console.error('Unable to write file', e);
                }
            }
            catch (e) {
                console.error('Unable to make directory', e);
            }
        });
    }
    loadJournal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.dateFormatted = [];
            this.journalContentFormatted = [];
            this.journals = [];
            this.showJournals = false;
            this.journalsLoaded = 0;
            Filesystem.readFile({
                path: 'Mirror-app/mirrorJournals.txt',
                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemDirectory"].Documents,
                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["FilesystemEncoding"].UTF8
            }).then(contents => {
                this.sortedJournals = JSON.parse(contents.data);
                this.sortedJournals.sort((a, b) => {
                    return Number(new Date(b.date)) - Number(new Date(a.date));
                });
                this.loadNextFiveJournals(1);
            }).catch(e => {
                console.error('file read err', e);
                this.createMirrorJournals();
                this.showJournals = false;
            });
        });
    }
    showWelcomeSceen() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _welcome_screen_welcome_screen_component__WEBPACK_IMPORTED_MODULE_11__["WelcomeScreenComponent"],
                backdropDismiss: false
            });
            yield modal.present();
        });
    }
    ionViewWillLeave() {
        // this.nativePageTransitions.slide(options);
        this.routerOutlet.swipeGesture = true;
    }
    // example of adding a transition when pushing a new page
    openJournalPage(page, journalToNavigate) {
        this.taptic.selection();
        // this.nativePageTransitions.slide(options);
        let navigationExtras;
        if (this.passcode !== undefined) {
            navigationExtras = {
                state: {
                    journal: journalToNavigate,
                    passcode: this.passcode
                }
            };
        }
        else {
            navigationExtras = {
                state: {
                    journal: journalToNavigate
                }
            };
        }
        this.navCtrl.navigateForward(page, navigationExtras);
    }
    openPage(page) {
        this.taptic.selection();
        this.navCtrl.navigateForward(page).then(() => { }).catch(err => {
            console.log('Error openPage: ' + err);
        });
    }
    openSettings() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.taptic.selection();
            const modal = yield this.modalController.create({
                component: _settings_settings_component__WEBPACK_IMPORTED_MODULE_7__["SettingsComponent"]
            });
            modal.onDidDismiss().then(() => {
                this.passcode = undefined;
                this.lockIcon = 'lock-closed-outline';
                this.loadJournal();
            });
            return yield modal.present();
        });
    }
    openPasswordDialog() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.taptic.notification({ type: 'warning' });
            const modal = yield this.modalController.create({
                component: _password_dialog_password_dialog_component__WEBPACK_IMPORTED_MODULE_9__["PasswordDialogComponent"]
            });
            modal.onDidDismiss().then(dataReturned => {
                if (dataReturned !== null && dataReturned.data !== '') {
                    this.passcode = dataReturned.data;
                }
                this.loadJournal();
            });
            return yield modal.present();
        });
    }
    askForPasscode() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'What is your passcode?',
                inputs: [{
                        name: 'passcode',
                        type: 'password',
                        placeholder: 'passcode',
                        attributes: {
                            inputmode: 'numeric',
                            pattern: '[0-9]*'
                        }
                    }],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Confirm Cancel');
                            this.passcode = undefined;
                            this.taptic.selection();
                        }
                    }, {
                        text: 'Ok',
                        handler: out => {
                            if (crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(this.passcode, out.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8) === 'passcode') {
                                this.passcode = out.passcode;
                                this.lockIcon = 'lock-open-outline';
                                this.taptic.notification({ type: 'success' });
                                this.loadJournal();
                            }
                            else {
                                this.passcode = undefined;
                                this.taptic.notification({ type: 'error' });
                                this.unlockLockJournals();
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    unlockLockJournals() {
        if (this.passcode === undefined) {
            this.nativeStorage.getItem('passcode').then((out) => {
                this.passcode = out;
                this.taptic.selection();
                this.askForPasscode();
            }).catch(err => {
                this.openPasswordDialog();
                console.log('Error unlocklock: ' + JSON.stringify(err));
            });
        }
        else {
            this.passcode = undefined;
            this.lockIcon = 'lock-closed-outline';
            this.loadJournal();
        }
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__["TapticEngine"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_native_page_transitions_ngx__WEBPACK_IMPORTED_MODULE_3__["NativePageTransitions"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonRouterOutlet"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__["NativeStorage"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"])
], HomePage.prototype, "infiniteScroll", void 0);
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map