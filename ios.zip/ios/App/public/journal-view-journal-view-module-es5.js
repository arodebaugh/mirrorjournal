function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["journal-view-journal-view-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppJournalViewJournalViewPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\" text=\"Home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ data.name }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>\n    <img *ngIf=\"data.headerImage !== undefined || data.headerImage !== null\" [src]=\"data.headerImage\" />\n    <ion-card-header>\n      <ion-card-subtitle style=\"text-align: center\">{{ dateFormatted }}</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <div style=\"text-align: center\">\n        <ion-chip color=\"primary\">\n          <ion-label>{{ data.mood }} Mood</ion-label>\n        </ion-chip>\n        <ion-chip color=\"primary\">\n          <ion-label>{{ data.activity }} Activity</ion-label>\n        </ion-chip>\n        <ion-chip color=\"primary\">\n          <ion-label *ngIf=\"data.notes !== undefined\" (click)=\"viewNotes()\">🔍 {{data.notes.length }} {{data.notes.length > 1 ? 'notes' : 'note'}}</ion-label>\n          <ion-label *ngIf=\"data.notes === undefined\">🔍 0 notes</ion-label>\n        </ion-chip>\n        <ion-chip color=\"danger\" *ngIf=\"data.expire != 'Never'\">\n          <ion-label>⌛ {{ timeToExpire }}</ion-label>\n        </ion-chip>\n      </div>\n    </ion-card-content>\n  </ion-card>\n\n  <div id=\"journal-display\" style=\"margin-left: 10pt; margin-right: 10pt;\">\n    <ion-text>\n      <div [innerHTML]=\"data.content\"></div>\n      <br /><br /><br />\n    </ion-text>\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" style=\"margin-bottom: 10pt;\">\n    <ion-fab-button>\n      <ion-icon name=\"cog\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"top\">\n      <ion-fab-button (click)=\"trashJournal()\"><ion-icon name=\"trash\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"start\">\n      <ion-fab-button (click)=\"analyzeJournal()\"><ion-icon name=\"search-outline\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"end\">\n      <ion-fab-button (click)=\"editJournal()\"><ion-icon name=\"create-outline\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/journal-view/journal-view-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/journal-view/journal-view-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: JournalViewPageRoutingModule */

  /***/
  function srcAppJournalViewJournalViewRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JournalViewPageRoutingModule", function () {
      return JournalViewPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _journal_view_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./journal-view.page */
    "./src/app/journal-view/journal-view.page.ts");

    var routes = [{
      path: '',
      component: _journal_view_page__WEBPACK_IMPORTED_MODULE_3__["JournalViewPage"]
    }];

    var JournalViewPageRoutingModule = function JournalViewPageRoutingModule() {
      _classCallCheck(this, JournalViewPageRoutingModule);
    };

    JournalViewPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], JournalViewPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/journal-view/journal-view.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/journal-view/journal-view.module.ts ***!
    \*****************************************************/

  /*! exports provided: JournalViewPageModule */

  /***/
  function srcAppJournalViewJournalViewModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JournalViewPageModule", function () {
      return JournalViewPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _journal_view_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./journal-view-routing.module */
    "./src/app/journal-view/journal-view-routing.module.ts");
    /* harmony import */


    var _journal_view_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./journal-view.page */
    "./src/app/journal-view/journal-view.page.ts");

    var JournalViewPageModule = function JournalViewPageModule() {
      _classCallCheck(this, JournalViewPageModule);
    };

    JournalViewPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _journal_view_routing_module__WEBPACK_IMPORTED_MODULE_5__["JournalViewPageRoutingModule"]],
      declarations: [_journal_view_page__WEBPACK_IMPORTED_MODULE_6__["JournalViewPage"]]
    })], JournalViewPageModule);
    /***/
  },

  /***/
  "./src/app/journal-view/journal-view.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/journal-view/journal-view.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppJournalViewJournalViewPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2pvdXJuYWwtdmlldy9qb3VybmFsLXZpZXcucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/journal-view/journal-view.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/journal-view/journal-view.page.ts ***!
    \***************************************************/

  /*! exports provided: JournalViewPage */

  /***/
  function srcAppJournalViewJournalViewPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JournalViewPage", function () {
      return JournalViewPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */


    var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/native-storage/ngx */
    "./node_modules/@ionic-native/native-storage/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _new_analyze_new_analyze_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../new-analyze/new-analyze.component */
    "./src/app/new-analyze/new-analyze.component.ts");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! crypto-js */
    "./node_modules/crypto-js/index.js");
    /* harmony import */


    var crypto_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_8__);
    /* harmony import */


    var _notes_list_notes_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../notes-list/notes-list.component */
    "./src/app/notes-list/notes-list.component.ts");
    /* harmony import */


    var _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/taptic-engine/ngx */
    "./node_modules/@ionic-native/taptic-engine/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");

    var Filesystem = _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["Plugins"].Filesystem;

    var JournalViewPage = /*#__PURE__*/function () {
      function JournalViewPage(taptic, modalController, alertController, routerOutlet, file, toastController, route, router, navCtrl, nativeStorage) {
        var _this = this;

        _classCallCheck(this, JournalViewPage);

        this.taptic = taptic;
        this.modalController = modalController;
        this.alertController = alertController;
        this.routerOutlet = routerOutlet;
        this.file = file;
        this.toastController = toastController;
        this.route = route;
        this.router = router;
        this.navCtrl = navCtrl;
        this.nativeStorage = nativeStorage;
        this.route.queryParams.subscribe(function (params) {
          if (_this.router.getCurrentNavigation().extras.state) {
            _this.data = _this.router.getCurrentNavigation().extras.state.journal;

            if (_this.router.getCurrentNavigation().extras.state.passcode) {
              _this.passcode = _this.router.getCurrentNavigation().extras.state.passcode;
            }

            _this.dateFormatted = moment__WEBPACK_IMPORTED_MODULE_4__(_this.data.date).format('LLLL');
          } else {
            _this.navCtrl.navigateBack('/');
          }
        });
      }

      _createClass(JournalViewPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {
          this.routerOutlet.swipeGesture = true;
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          var timeToExpireString = this.data.expire.split(' ');
          var timeToExpireMoment = moment__WEBPACK_IMPORTED_MODULE_4__(this.data.date);
          var hourDiff = moment__WEBPACK_IMPORTED_MODULE_4__().diff(timeToExpireMoment, 'hours');
          var hoursToCountdown;

          if (timeToExpireString[1] === 'Days' || timeToExpireString[1] === 'Day') {
            hoursToCountdown = timeToExpireString[0] * 24;
          } else if (timeToExpireString[1] === 'Weeks' || timeToExpireString[1] === 'Week') {
            hoursToCountdown = timeToExpireString[0] * 7 * 24;
          } else if (timeToExpireString[1] === 'Months' || timeToExpireString[1] === 'Month') {
            hoursToCountdown = timeToExpireString[0] * 30 * 24;
          } else if (timeToExpireString[1] === 'Years' || timeToExpireString[1] === 'Year') {
            hoursToCountdown = timeToExpireString[0] * 365 * 24;
          }

          var hoursLeft = Math.round(hoursToCountdown - hourDiff);

          if (hoursLeft < 0) {
            alert('This should have been deleted?');
          } else {
            this.timeToExpire = '';
            var yearsLeft = Math.floor(hoursLeft / 8760);
            hoursLeft = hoursLeft % 8760;
            var monthsLeft = Math.floor(hoursLeft / 720);
            hoursLeft = hoursLeft % 720;
            var weeksLeft = Math.floor(hoursLeft / 168);
            hoursLeft = hoursLeft % 168;
            var daysLeft = Math.floor(hoursLeft / 24);
            hoursLeft = hoursLeft % 24;

            if (yearsLeft > 1) {
              this.timeToExpire += yearsLeft + ' Years';
            } else if (yearsLeft === 1) {
              this.timeToExpire += yearsLeft + ' Year';
            }

            if (monthsLeft > 1) {
              this.timeToExpire += ' ' + yearsLeft + ' Months';
            } else if (monthsLeft === 1) {
              this.timeToExpire += ' ' + yearsLeft + ' Month';
            }

            if (weeksLeft > 1) {
              this.timeToExpire += ' ' + weeksLeft + ' Weeks';
            } else if (weeksLeft === 1) {
              this.timeToExpire += ' ' + weeksLeft + ' Week';
            }

            if (daysLeft > 1) {
              this.timeToExpire += ' ' + daysLeft + ' Days';
            } else if (daysLeft === 1) {
              this.timeToExpire += ' ' + daysLeft + ' Day';
            }

            if (hoursLeft > 1) {
              this.timeToExpire += ' ' + hoursLeft + ' Hours';
            } else if (hoursLeft === 1) {
              this.timeToExpire += ' ' + hoursLeft + ' Hour';
            }

            this.timeToExpire = this.timeToExpire.trim();
          }
        }
      }, {
        key: "deleteJournal",
        value: function deleteJournal(toast) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var data, contents, outParsed, i, result;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    data = this.data;
                    _context.next = 3;
                    return Filesystem.readFile({
                      path: 'Mirror-app/mirrorJournals.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
                    });

                  case 3:
                    contents = _context.sent;
                    outParsed = JSON.parse(contents.data);
                    _context.t0 = regeneratorRuntime.keys(outParsed);

                  case 6:
                    if ((_context.t1 = _context.t0()).done) {
                      _context.next = 28;
                      break;
                    }

                    i = _context.t1.value;

                    if (!outParsed.hasOwnProperty(i)) {
                      _context.next = 26;
                      break;
                    }

                    if (!(outParsed[i].id === data.id)) {
                      _context.next = 26;
                      break;
                    }

                    outParsed = outParsed.filter(function (returnableObjects) {
                      return returnableObjects.id !== data.id;
                    });
                    _context.next = 13;
                    return Filesystem.deleteFile({
                      path: 'Mirror-app/' + data.id + '.txt',
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents
                    });

                  case 13:
                    _context.prev = 13;
                    _context.next = 16;
                    return Filesystem.writeFile({
                      path: 'Mirror-app/mirrorJournals.txt',
                      data: JSON.stringify(outParsed),
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
                    });

                  case 16:
                    result = _context.sent;
                    this.taptic.notification({
                      type: 'success'
                    });
                    toast.present();
                    this.navCtrl.navigateBack('/');
                    console.log('Wrote file', result);
                    _context.next = 26;
                    break;

                  case 23:
                    _context.prev = 23;
                    _context.t2 = _context["catch"](13);
                    console.error('Unable to write file', _context.t2);

                  case 26:
                    _context.next = 6;
                    break;

                  case 28:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this, [[13, 23]]);
          }));
        }
      }, {
        key: "trashJournal",
        value: function trashJournal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var toast, alert;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      message: 'Your journal \'' + this.data.name + '\' has been deleted.',
                      position: 'top',
                      color: 'primary',
                      duration: 2000,
                      buttons: [{
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    toast = _context2.sent;
                    _context2.next = 5;
                    return this.alertController.create({
                      header: '🚨 Are you sure? 🚨',
                      message: 'This action cannot be reversed.',
                      buttons: [{
                        text: 'Never mind',
                        role: 'cancel'
                      }, {
                        text: 'Delete',
                        cssClass: 'danger',
                        handler: function handler() {
                          _this2.deleteJournal(toast);
                        }
                      }]
                    });

                  case 5:
                    alert = _context2.sent;
                    _context2.next = 8;
                    return alert.present();

                  case 8:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "askForPasscode",
        value: function askForPasscode(modal) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      message: 'What is your passcode?',
                      inputs: [{
                        name: 'passcode',
                        type: 'password',
                        placeholder: 'passcode',
                        attributes: {
                          inputmode: 'numeric',
                          pattern: '[0-9]*'
                        }
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                          _this3.passcode = undefined;

                          _this3.taptic.selection();
                        }
                      }, {
                        text: 'Ok',
                        handler: function handler(out) {
                          if (crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(_this3.passcode, out.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8) === 'passcode') {
                            _this3.taptic.selection();

                            _this3.passcode = out.passcode;
                            modal.present();
                          } else {
                            _this3.askForPasscode(modal);
                          }
                        }
                      }]
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "saveNoteToFile",
        value: function saveNoteToFile(saveData, toast) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var fileName, result;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    fileName = 'Mirror-app/' + this.data.id + '.txt';
                    _context4.prev = 1;
                    _context4.next = 4;
                    return Filesystem.writeFile({
                      path: fileName,
                      data: JSON.stringify(this.data),
                      directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                      encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
                    });

                  case 4:
                    result = _context4.sent;
                    console.log('Wrote file', result);
                    toast.present();
                    _context4.next = 12;
                    break;

                  case 9:
                    _context4.prev = 9;
                    _context4.t0 = _context4["catch"](1);
                    console.error('Unable to write file', _context4.t0);

                  case 12:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this, [[1, 9]]);
          }));
        }
      }, {
        key: "tryToEncrypt",
        value: function tryToEncrypt(saveData, toast) {
          if (this.data.locked) {
            this.data.content = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].encrypt(this.data.content, this.passcode).toString();
            this.data.notes = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].encrypt(this.data.notes, this.passcode).toString();
          }

          this.saveNoteToFile(saveData, toast);
        }
      }, {
        key: "analyzeJournal",
        value: function analyzeJournal() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this4 = this;

            var toast, modal;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.toastController.create({
                      message: 'Your note has been saved!',
                      position: 'top',
                      color: 'primary',
                      duration: 2000,
                      buttons: [{
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    toast = _context5.sent;
                    _context5.next = 5;
                    return this.modalController.create({
                      component: _new_analyze_new_analyze_component__WEBPACK_IMPORTED_MODULE_6__["NewAnalyzeComponent"],
                      componentProps: {
                        pickerName: 'New Note',
                        data: this.data,
                        newNote: true
                      }
                    });

                  case 5:
                    modal = _context5.sent;
                    modal.onDidDismiss().then(function (dataReturned) {
                      if (dataReturned !== null && dataReturned.data !== undefined) {
                        console.log(JSON.stringify(dataReturned.data));

                        if (_this4.data.notes) {
                          _this4.data.notes.push(dataReturned.data);
                        } else {
                          _this4.data.notes = [dataReturned.data];
                        }

                        _this4.data.notes = _this4.data.notes.filter(function (e) {
                          return e;
                        });

                        _this4.tryToEncrypt(_this4.data, toast);
                      }
                    });

                    if (!this.data.locked) {
                      _context5.next = 11;
                      break;
                    }

                    this.nativeStorage.getItem('passcode').then(function (out) {
                      _this4.passcode = out;

                      _this4.askForPasscode(modal);
                    })["catch"](function (err) {
                      alert('Error getting passcode ' + err);
                    });
                    _context5.next = 14;
                    break;

                  case 11:
                    this.taptic.selection();
                    _context5.next = 14;
                    return modal.present();

                  case 14:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "viewNotes",
        value: function viewNotes() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var _this5 = this;

            var toast, modal;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.toastController.create({
                      message: 'Your note has been deleted!',
                      position: 'top',
                      color: 'primary',
                      duration: 2000,
                      buttons: [{
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    toast = _context6.sent;
                    this.taptic.selection();
                    _context6.next = 6;
                    return this.modalController.create({
                      component: _notes_list_notes_list_component__WEBPACK_IMPORTED_MODULE_9__["NotesListComponent"],
                      componentProps: {
                        notes: this.data.notes
                      }
                    });

                  case 6:
                    modal = _context6.sent;
                    modal.onDidDismiss().then(function (dataReturned) {
                      if (dataReturned !== null && dataReturned.data !== undefined) {
                        if (dataReturned.data === 1) {
                          _this5.analyzeJournal();
                        } else {
                          _this5.data.notes = _this5.data.notes.filter(function (f) {
                            return f !== dataReturned.data;
                          });

                          _this5.tryToEncrypt(_this5.data, toast);
                        }
                      } else {
                        _this5.taptic.selection();
                      }
                    });
                    _context6.next = 10;
                    return modal.present();

                  case 10:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "editJournal",
        value: function editJournal() {
          this.taptic.selection();
          var navigationExtras;

          if (this.passcode) {
            navigationExtras = {
              state: {
                journalName: this.data.name,
                expireLabelText: this.data.expire,
                mood: this.data.mood,
                activity: this.data.activity,
                created: this.data.date,
                journalContent: this.data.content,
                journalID: this.data.id,
                headerImageData: this.data.headerImage,
                lockState: this.data.locked,
                passcode: this.passcode
              }
            };
          } else {
            navigationExtras = {
              state: {
                journalName: this.data.name,
                expireLabelText: this.data.expire,
                mood: this.data.mood,
                activity: this.data.activity,
                created: this.data.date,
                journalContent: this.data.content,
                journalID: this.data.id,
                headerImageData: this.data.headerImage,
                lockState: this.data.locked
              }
            };
          }

          this.navCtrl.navigateForward('/journal-new', navigationExtras);
        }
      }]);

      return JournalViewPage;
    }();

    JournalViewPage.ctorParameters = function () {
      return [{
        type: _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__["TapticEngine"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonRouterOutlet"]
      }, {
        type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__["NativeStorage"]
      }];
    };

    JournalViewPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-journal-view',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./journal-view.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./journal-view.page.scss */
      "./src/app/journal-view/journal-view.page.scss"))["default"]]
    })], JournalViewPage);
    /***/
  }
}]);
//# sourceMappingURL=journal-view-journal-view-module-es5.js.map