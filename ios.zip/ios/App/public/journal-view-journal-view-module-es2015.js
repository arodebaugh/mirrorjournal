(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["journal-view-journal-view-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\" text=\"Home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ data.name }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>\n    <img *ngIf=\"data.headerImage !== undefined || data.headerImage !== null\" [src]=\"data.headerImage\" />\n    <ion-card-header>\n      <ion-card-subtitle style=\"text-align: center\">{{ dateFormatted }}</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n      <div style=\"text-align: center\">\n        <ion-chip color=\"primary\">\n          <ion-label>{{ data.mood }} Mood</ion-label>\n        </ion-chip>\n        <ion-chip color=\"primary\">\n          <ion-label>{{ data.activity }} Activity</ion-label>\n        </ion-chip>\n        <ion-chip color=\"primary\">\n          <ion-label *ngIf=\"data.notes !== undefined\" (click)=\"viewNotes()\">🔍 {{data.notes.length }} {{data.notes.length > 1 ? 'notes' : 'note'}}</ion-label>\n          <ion-label *ngIf=\"data.notes === undefined\">🔍 0 notes</ion-label>\n        </ion-chip>\n        <ion-chip color=\"danger\" *ngIf=\"data.expire != 'Never'\">\n          <ion-label>⌛ {{ timeToExpire }}</ion-label>\n        </ion-chip>\n      </div>\n    </ion-card-content>\n  </ion-card>\n\n  <div id=\"journal-display\" style=\"margin-left: 10pt; margin-right: 10pt;\">\n    <ion-text>\n      <div [innerHTML]=\"data.content\"></div>\n      <br /><br /><br />\n    </ion-text>\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\" style=\"margin-bottom: 10pt;\">\n    <ion-fab-button>\n      <ion-icon name=\"cog\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list side=\"top\">\n      <ion-fab-button (click)=\"trashJournal()\"><ion-icon name=\"trash\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"start\">\n      <ion-fab-button (click)=\"analyzeJournal()\"><ion-icon name=\"search-outline\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n    <ion-fab-list side=\"end\">\n      <ion-fab-button (click)=\"editJournal()\"><ion-icon name=\"create-outline\"></ion-icon></ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/journal-view/journal-view-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/journal-view/journal-view-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: JournalViewPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JournalViewPageRoutingModule", function() { return JournalViewPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _journal_view_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./journal-view.page */ "./src/app/journal-view/journal-view.page.ts");




const routes = [
    {
        path: '',
        component: _journal_view_page__WEBPACK_IMPORTED_MODULE_3__["JournalViewPage"]
    }
];
let JournalViewPageRoutingModule = class JournalViewPageRoutingModule {
};
JournalViewPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], JournalViewPageRoutingModule);



/***/ }),

/***/ "./src/app/journal-view/journal-view.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/journal-view/journal-view.module.ts ***!
  \*****************************************************/
/*! exports provided: JournalViewPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JournalViewPageModule", function() { return JournalViewPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _journal_view_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./journal-view-routing.module */ "./src/app/journal-view/journal-view-routing.module.ts");
/* harmony import */ var _journal_view_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./journal-view.page */ "./src/app/journal-view/journal-view.page.ts");







let JournalViewPageModule = class JournalViewPageModule {
};
JournalViewPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _journal_view_routing_module__WEBPACK_IMPORTED_MODULE_5__["JournalViewPageRoutingModule"]
        ],
        declarations: [_journal_view_page__WEBPACK_IMPORTED_MODULE_6__["JournalViewPage"]]
    })
], JournalViewPageModule);



/***/ }),

/***/ "./src/app/journal-view/journal-view.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/journal-view/journal-view.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2pvdXJuYWwtdmlldy9qb3VybmFsLXZpZXcucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/journal-view/journal-view.page.ts":
/*!***************************************************!*\
  !*** ./src/app/journal-view/journal-view.page.ts ***!
  \***************************************************/
/*! exports provided: JournalViewPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JournalViewPage", function() { return JournalViewPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _new_analyze_new_analyze_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../new-analyze/new-analyze.component */ "./src/app/new-analyze/new-analyze.component.ts");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _notes_list_notes_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../notes-list/notes-list.component */ "./src/app/notes-list/notes-list.component.ts");
/* harmony import */ var _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/taptic-engine/ngx */ "./node_modules/@ionic-native/taptic-engine/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");












const { Filesystem } = _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["Plugins"];
let JournalViewPage = class JournalViewPage {
    constructor(taptic, modalController, alertController, routerOutlet, file, toastController, route, router, navCtrl, nativeStorage) {
        this.taptic = taptic;
        this.modalController = modalController;
        this.alertController = alertController;
        this.routerOutlet = routerOutlet;
        this.file = file;
        this.toastController = toastController;
        this.route = route;
        this.router = router;
        this.navCtrl = navCtrl;
        this.nativeStorage = nativeStorage;
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.data = this.router.getCurrentNavigation().extras.state.journal;
                if (this.router.getCurrentNavigation().extras.state.passcode) {
                    this.passcode = this.router.getCurrentNavigation().extras.state.passcode;
                }
                this.dateFormatted = moment__WEBPACK_IMPORTED_MODULE_4__(this.data.date).format('LLLL');
            }
            else {
                this.navCtrl.navigateBack('/');
            }
        });
    }
    ngOnInit() {
    }
    ionViewWillLeave() {
        this.routerOutlet.swipeGesture = true;
    }
    ionViewDidEnter() {
        const timeToExpireString = this.data.expire.split(' ');
        const timeToExpireMoment = moment__WEBPACK_IMPORTED_MODULE_4__(this.data.date);
        const hourDiff = moment__WEBPACK_IMPORTED_MODULE_4__().diff(timeToExpireMoment, 'hours');
        let hoursToCountdown;
        if (timeToExpireString[1] === 'Days' || timeToExpireString[1] === 'Day') {
            hoursToCountdown = timeToExpireString[0] * 24;
        }
        else if (timeToExpireString[1] === 'Weeks' || timeToExpireString[1] === 'Week') {
            hoursToCountdown = (timeToExpireString[0] * 7) * 24;
        }
        else if (timeToExpireString[1] === 'Months' || timeToExpireString[1] === 'Month') {
            hoursToCountdown = (timeToExpireString[0] * 30) * 24;
        }
        else if (timeToExpireString[1] === 'Years' || timeToExpireString[1] === 'Year') {
            hoursToCountdown = (timeToExpireString[0] * 365) * 24;
        }
        let hoursLeft = Math.round(hoursToCountdown - hourDiff);
        if (hoursLeft < 0) {
            alert('This should have been deleted?');
        }
        else {
            this.timeToExpire = '';
            const yearsLeft = Math.floor(hoursLeft / 8760);
            hoursLeft = hoursLeft % 8760;
            const monthsLeft = Math.floor(hoursLeft / 720);
            hoursLeft = hoursLeft % 720;
            const weeksLeft = Math.floor(hoursLeft / 168);
            hoursLeft = hoursLeft % 168;
            const daysLeft = Math.floor(hoursLeft / 24);
            hoursLeft = hoursLeft % 24;
            if (yearsLeft > 1) {
                this.timeToExpire += yearsLeft + ' Years';
            }
            else if (yearsLeft === 1) {
                this.timeToExpire += yearsLeft + ' Year';
            }
            if (monthsLeft > 1) {
                this.timeToExpire += ' ' + yearsLeft + ' Months';
            }
            else if (monthsLeft === 1) {
                this.timeToExpire += ' ' + yearsLeft + ' Month';
            }
            if (weeksLeft > 1) {
                this.timeToExpire += ' ' + weeksLeft + ' Weeks';
            }
            else if (weeksLeft === 1) {
                this.timeToExpire += ' ' + weeksLeft + ' Week';
            }
            if (daysLeft > 1) {
                this.timeToExpire += ' ' + daysLeft + ' Days';
            }
            else if (daysLeft === 1) {
                this.timeToExpire += ' ' + daysLeft + ' Day';
            }
            if (hoursLeft > 1) {
                this.timeToExpire += ' ' + hoursLeft + ' Hours';
            }
            else if (hoursLeft === 1) {
                this.timeToExpire += ' ' + hoursLeft + ' Hour';
            }
            this.timeToExpire = this.timeToExpire.trim();
        }
    }
    deleteJournal(toast) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const data = this.data;
            const contents = yield Filesystem.readFile({
                path: 'Mirror-app/mirrorJournals.txt',
                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
            });
            let outParsed = JSON.parse(contents.data);
            for (const i in outParsed) {
                if (outParsed.hasOwnProperty(i)) {
                    if (outParsed[i].id === data.id) {
                        outParsed = outParsed.filter(returnableObjects => returnableObjects.id !== data.id);
                        yield Filesystem.deleteFile({
                            path: 'Mirror-app/' + data.id + '.txt',
                            directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents
                        });
                        try {
                            const result = yield Filesystem.writeFile({
                                path: 'Mirror-app/mirrorJournals.txt',
                                data: JSON.stringify(outParsed),
                                directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                                encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
                            });
                            this.taptic.notification({ type: 'success' });
                            toast.present();
                            this.navCtrl.navigateBack('/');
                            console.log('Wrote file', result);
                        }
                        catch (e) {
                            console.error('Unable to write file', e);
                        }
                    }
                }
            }
        });
    }
    trashJournal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Your journal \'' + this.data.name + '\' has been deleted.',
                position: 'top',
                color: 'primary',
                duration: 2000,
                buttons: [
                    {
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }
                ]
            });
            const alert = yield this.alertController.create({
                header: '🚨 Are you sure? 🚨',
                message: 'This action cannot be reversed.',
                buttons: [
                    {
                        text: 'Never mind',
                        role: 'cancel'
                    }, {
                        text: 'Delete',
                        cssClass: 'danger',
                        handler: () => {
                            this.deleteJournal(toast);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    askForPasscode(modal) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'What is your passcode?',
                inputs: [{
                        name: 'passcode',
                        type: 'password',
                        placeholder: 'passcode',
                        attributes: {
                            inputmode: 'numeric',
                            pattern: '[0-9]*'
                        }
                    }],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Confirm Cancel');
                            this.passcode = undefined;
                            this.taptic.selection();
                        }
                    }, {
                        text: 'Ok',
                        handler: out => {
                            if (crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].decrypt(this.passcode, out.passcode).toString(crypto_js__WEBPACK_IMPORTED_MODULE_8__["enc"].Utf8) === 'passcode') {
                                this.taptic.selection();
                                this.passcode = out.passcode;
                                modal.present();
                            }
                            else {
                                this.askForPasscode(modal);
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    saveNoteToFile(saveData, toast) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const fileName = 'Mirror-app/' + this.data.id + '.txt';
            try {
                const result = yield Filesystem.writeFile({
                    path: fileName,
                    data: JSON.stringify(this.data),
                    directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemDirectory"].Documents,
                    encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["FilesystemEncoding"].UTF8
                });
                console.log('Wrote file', result);
                toast.present();
            }
            catch (e) {
                console.error('Unable to write file', e);
            }
        });
    }
    tryToEncrypt(saveData, toast) {
        if (this.data.locked) {
            this.data.content = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].encrypt(this.data.content, this.passcode).toString();
            this.data.notes = crypto_js__WEBPACK_IMPORTED_MODULE_8__["AES"].encrypt(this.data.notes, this.passcode).toString();
        }
        this.saveNoteToFile(saveData, toast);
    }
    analyzeJournal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Your note has been saved!',
                position: 'top',
                color: 'primary',
                duration: 2000,
                buttons: [
                    {
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }
                ]
            });
            const modal = yield this.modalController.create({
                component: _new_analyze_new_analyze_component__WEBPACK_IMPORTED_MODULE_6__["NewAnalyzeComponent"],
                componentProps: {
                    pickerName: 'New Note',
                    data: this.data,
                    newNote: true
                }
            });
            modal.onDidDismiss().then(dataReturned => {
                if (dataReturned !== null && dataReturned.data !== undefined) {
                    console.log(JSON.stringify(dataReturned.data));
                    if (this.data.notes) {
                        this.data.notes.push(dataReturned.data);
                    }
                    else {
                        this.data.notes = [dataReturned.data];
                    }
                    this.data.notes = this.data.notes.filter(e => e);
                    this.tryToEncrypt(this.data, toast);
                }
            });
            if (this.data.locked) {
                this.nativeStorage.getItem('passcode').then((out) => {
                    this.passcode = out;
                    this.askForPasscode(modal);
                }).catch(err => {
                    alert('Error getting passcode ' + err);
                });
            }
            else {
                this.taptic.selection();
                yield modal.present();
            }
        });
    }
    viewNotes() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Your note has been deleted!',
                position: 'top',
                color: 'primary',
                duration: 2000,
                buttons: [
                    {
                        text: 'Dismiss',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }
                ]
            });
            this.taptic.selection();
            const modal = yield this.modalController.create({
                component: _notes_list_notes_list_component__WEBPACK_IMPORTED_MODULE_9__["NotesListComponent"],
                componentProps: {
                    notes: this.data.notes
                }
            });
            modal.onDidDismiss().then(dataReturned => {
                if (dataReturned !== null && dataReturned.data !== undefined) {
                    if (dataReturned.data === 1) {
                        this.analyzeJournal();
                    }
                    else {
                        this.data.notes = this.data.notes.filter(f => f !== dataReturned.data);
                        this.tryToEncrypt(this.data, toast);
                    }
                }
                else {
                    this.taptic.selection();
                }
            });
            yield modal.present();
        });
    }
    editJournal() {
        this.taptic.selection();
        let navigationExtras;
        if (this.passcode) {
            navigationExtras = {
                state: {
                    journalName: this.data.name,
                    expireLabelText: this.data.expire,
                    mood: this.data.mood,
                    activity: this.data.activity,
                    created: this.data.date,
                    journalContent: this.data.content,
                    journalID: this.data.id,
                    headerImageData: this.data.headerImage,
                    lockState: this.data.locked,
                    passcode: this.passcode
                }
            };
        }
        else {
            navigationExtras = {
                state: {
                    journalName: this.data.name,
                    expireLabelText: this.data.expire,
                    mood: this.data.mood,
                    activity: this.data.activity,
                    created: this.data.date,
                    journalContent: this.data.content,
                    journalID: this.data.id,
                    headerImageData: this.data.headerImage,
                    lockState: this.data.locked
                }
            };
        }
        this.navCtrl.navigateForward('/journal-new', navigationExtras);
    }
};
JournalViewPage.ctorParameters = () => [
    { type: _ionic_native_taptic_engine_ngx__WEBPACK_IMPORTED_MODULE_10__["TapticEngine"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonRouterOutlet"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__["NativeStorage"] }
];
JournalViewPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-journal-view',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./journal-view.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/journal-view/journal-view.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./journal-view.page.scss */ "./src/app/journal-view/journal-view.page.scss")).default]
    })
], JournalViewPage);



/***/ })

}]);
//# sourceMappingURL=journal-view-journal-view-module-es2015.js.map